# Machine Learning with Quantum Computing
* Project Advisor: Prof. Vijay Eranti
* Team Members:
&nbsp;&nbsp; Allen Wu (yanshiun.wu@sjsu.edu)  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Govinder Somal (govinder.somal@sjsu.edu)  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Zi Shun Yang (zishun.yang@sjsu.edu)  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Abraham Kong (abraham.kong@sjsu.edu)  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Sharad Nataraj (sharad.nataraj@sjsu.edu)  

* [JIRA Kanban](https://project-qml.atlassian.net/jira/software/projects/PQ/boards/1) 

## CMPE-295A (Sept. 14)
* [Project Formation](https://docs.google.com/presentation/d/1gxzTDM5bf6O7oC5Dm5F9nwSCXUtHeQBv/edit?usp=sharing&ouid=114892984865008798611&rtpof=true&sd=true)
* [Project Abstract](https://docs.google.com/document/d/1okScdm_As1KF0R4Rsf1Ntgd-7y-cro3A/edit?usp=sharing&ouid=114892984865008798611&rtpof=true&sd=true)
