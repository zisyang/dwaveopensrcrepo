import pandas as pd
from sqlalchemy import create_engine
import psycopg2

#INPUT YOUR OWN CONNECTION STRING HERE
conn_string = 'postgresql://postgres:pass@localhost:5433/test'

#Import .csv file
df = pd.read_csv('train.csv')

#perform to_sql
db = create_engine(conn_string)
conn = db.connect()

df.to_sql('titanic_dataset', con=conn, if_exists='replace', index=False)
