import numpy as np
import dimod
from dwave.system import DWaveSampler, FixedEmbeddingComposite
from minorminer.busclique import find_clique_embedding
import itertools
from hybrid.reference.kerberos import KerberosSampler
import pandas as pd

def prob(dataset, max_bins=10):
    """Joint probability distribution P(X) for the given data."""

    # bin by the number of different values per feature
    num_rows, num_columns = dataset.shape
    bins = [min(len(np.unique(dataset[:, ci])), max_bins) for ci in range(num_columns)]

    freq, _ = np.histogramdd(dataset, bins)
    p = freq / np.sum(freq)
    return p

def shannon_entropy(p):
    """Shannon entropy H(X) is the sum of P(X)log(P(X)) for probabilty distribution P(X)."""
    p = p.flatten()
    return -sum(pi*np.log2(pi) for pi in p if pi)

def conditional_shannon_entropy(p, *conditional_indices):
    """Shannon entropy of P(X) conditional on variable j"""

    axis = tuple(i for i in np.arange(len(p.shape)) if i not in conditional_indices)

    return shannon_entropy(p) - shannon_entropy(np.sum(p, axis=axis))

def mutual_information(p, j):
    """Mutual information between all variables and variable j"""
    return shannon_entropy(np.sum(p, axis=j)) - conditional_shannon_entropy(p, j)
    
def conditional_mutual_information(p, j, *conditional_indices):
    """Mutual information between variables X and variable Y conditional on variable Z."""

    marginal_conditional_indices = [i-1 if i > j else i for i in conditional_indices]

    return (conditional_shannon_entropy(np.sum(p, axis=j), *marginal_conditional_indices)
            - conditional_shannon_entropy(p, j, *conditional_indices))

    
def classical_MI(df):

  label = 'Survived' # label for mutual information interest
  mi = {}
  features = list(set(df.columns).difference((label,)))

  for feature in features:
    mi[feature] = mutual_information(prob(df[[label, feature]].values), 1)

  # Select 8 features with the top MI ranking found above. 
  keep = 8

  sorted_mi = sorted(mi.items(), key=lambda pair: pair[1], reverse=True)
  df = df[[column[0] for column in sorted_mi[0:keep]] + [label]]
  features = list(set(df.columns).difference((label,)))

  # print("Submitting for {} features: {}".format(keep, features))

  return df[features]


def MIQUBO(df):

  label = 'Survived' # label for mutual information interest
  mi = {}
  features = list(set(df.columns).difference((label,)))

  for feature in features:
    mi[feature] = mutual_information(prob(df[[label, feature]].values), 1)

  # Select 8 features with the top MI ranking found above. 
  keep = 8

  sorted_mi = sorted(mi.items(), key=lambda pair: pair[1], reverse=True)
  df = df[[column[0] for column in sorted_mi[0:keep]] + [label]]
  features = list(set(df.columns).difference((label,)))

  # Calculate a BQM based on the problem's MI and CMI as done previously for the toy problem.

  bqm = dimod.BinaryQuadraticModel.empty(dimod.BINARY)

  # add the features
  for feature in features:
    mi = mutual_information(prob(df[['Survived', feature]].values), 1)
    bqm.add_variable(feature, -mi)

  for f0, f1 in itertools.combinations(features, 2):
    cmi_01 = conditional_mutual_information(prob(df[['Survived', f0, f1]].values), 1, 2)
    cmi_10 = conditional_mutual_information(prob(df[['Survived', f1, f0]].values), 1, 2)
    bqm.add_interaction(f0, f1, -cmi_01)
    bqm.add_interaction(f1, f0, -cmi_10)

  bqm.normalize()
  
  endpoint = 'https://cloud.dwavesys.com/sapi'
  token = 'DEV-8ee4cb649cb2e3809607fce6c1f620cd8cd5918f'
  solver = 'DW_2000Q_6'

  # qpu = DWaveSampler()
  qpu = DWaveSampler(endpoint=endpoint, token=token, solver=solver)

  qpu_working_graph = qpu.to_networkx_graph()
  embedding = find_clique_embedding(bqm.variables, qpu_working_graph)
  num_qubits = sum(len(chain) for chain in embedding.values())

  qpu_sampler = FixedEmbeddingComposite(qpu, embedding)

  kerberos_sampler = KerberosSampler() 

  MAX_TIME = 500000   # limit single-problem submissions to 0.5 seconds
  num_reads = 50
  anneal_schedule = [[0.0, 0.0], [40.0, 0.4], [1040.0, 0.4], [1042, 1.0]]
  estimated_runtime = qpu.solver.estimate_qpu_access_time(num_qubits,
    num_reads=num_reads, anneal_schedule=anneal_schedule)    
  # print("Estimate of {:.0f}us on {}".format(estimated_runtime, qpu.solver.name))  
  # Estimate of 75005us on Advantage_system4.1

  if estimated_runtime < MAX_TIME:
    qpu_sampler_min = FixedEmbeddingComposite(qpu, embedding).sample(bqm,
        num_reads=num_reads, anneal_schedule=anneal_schedule)
  
  selected_features = np.zeros((len(features), len(features)))
  for k in range(1, len(features) + 1):
    # print("Submitting for k={}".format(k))
    kbqm = dimod.generators.combinations(features, k, strength=6)
    kbqm.update(bqm)
    kbqm.normalize()
    
    best = kerberos_sampler.sample(kbqm, 
                                   qpu_sampler=qpu_sampler, 
                                   qpu_reads=1000, 
                                   max_iter=10,
                                   qpu_params={'label': 'Notebook - Feature Selection'}
                                  ).first.sample
    
  for fi, f in enumerate(features):
    selected_features[k-1, fi] = best[f]

  keysList = list(best.keys())
  best_pd = df[keysList]

  return best_pd
    

########## Feature Selection API ##################################################

def quantum_feature_selection(input_dataset_pd):
  """ 
  :quantum_feature_selection
  :param input_dataset_pd: Dataset without Feature Selection
  :return: df_feature_selected
  """
  df_feature_selected = MIQUBO(input_dataset_pd)
  return df_feature_selected

def classical_feature_selection(input_dataset_pd):
  """ 
  :classical_feature_selection
  :param input_dataset_pd: Dataset without Feature Selection
  :return: df_feature_selected
  """
  # train_model = train_machine_learning_process(input_training_dataset_pd, mode='c') # mode: c=classical
  # output_accuracy_float = model(train_model, input_testing_dataset_pd)
  df_feature_selected = classical_MI(input_dataset_pd)
  return df_feature_selected