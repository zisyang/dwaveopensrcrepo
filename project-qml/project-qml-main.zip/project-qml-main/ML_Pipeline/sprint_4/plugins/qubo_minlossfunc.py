# import necessary packages
import numpy as np
from sklearn import preprocessing, metrics
from sklearn.ensemble import AdaBoostClassifier, RandomForestClassifier
from sklearn.datasets import fetch_openml
# from sklearn.datasets import load_breast_cancer
from dwave.system.samplers import DWaveSampler
from dwave.system.composites import EmbeddingComposite
from sklearn.impute import SimpleImputer
from qboost import WeakClassifiers, QBoostClassifier, QboostPlus

endpoint = 'https://cloud.dwavesys.com/sapi'
token = 'DEV-08d7ed5dda6e3129eda429e5268b438989582e7f'
solver = 'DW_2000Q_6'  ## QPU solver

def train_machine_learning_process(input_training_dataset_pd, mode='q'): # mode: q=quantum, c=classical
  """ 
  :param input_training_dataset_pd: Train Dataset (Pandas Dataframe)
  :param mode: Training mode, q='Quantum', c='Classical'
  :return: trained_model, list of classifiers
  """

  # dataset preparation ...
  """
  :param X_train: training data
  :param y_train: training label
  :param lmd: lambda used in regularization
  """
  label = 'Survived' # label for labeling training set, change it upon your preference
  X_train = input_training_dataset_pd.loc[:,input_training_dataset_pd.columns!=label]
  y_train = 2*(input_training_dataset_pd[label]>0) - 1
  lmd=1.0

  # define parameters used in this function
  NUM_READS = 1000
  NUM_WEAK_CLASSIFIERS = 30
  TREE_DEPTH = 2
  DW_PARAMS = {'num_reads': NUM_READS,
                'auto_scale': True,
                'num_spin_reversal_transforms': 10,
                'postprocess': 'optimization',
                }

  # define sampler
  # dwave_sampler = DWaveSampler() ##
  dwave_sampler = DWaveSampler(endpoint=endpoint, token=token, solver=solver) # client='base' use for hybrid solver

  emb_sampler = EmbeddingComposite(dwave_sampler)

  N_train = len(X_train)
  print("\n======================================")
  print("Train size: %d" % N_train)
  print('Num weak classifiers:', NUM_WEAK_CLASSIFIERS)

  # Preprocessing data
  # imputer = preprocessing.Imputer()
  imputer = SimpleImputer(missing_values=np.nan, strategy='mean')
  scaler = preprocessing.StandardScaler()
  normalizer = preprocessing.Normalizer()

  X_train = scaler.fit_transform(X_train)
  X_train = normalizer.fit_transform(X_train)

  clfs = []

  if mode is 'c':
    print('doing classical...')

    ## Adaboost
    print('\nAdaboost')
    clf1 = AdaBoostClassifier(n_estimators=NUM_WEAK_CLASSIFIERS)
    clf1.fit(X_train, y_train)
    y_train1 = clf1.predict(X_train)
    print('accu (train): %5.2f'%(metric(y_train, y_train1)))

    # Ensembles of Decision Tree
    print('\nDecision tree')
    clf2 = WeakClassifiers(n_estimators=NUM_WEAK_CLASSIFIERS, max_depth=TREE_DEPTH)
    clf2.fit(X_train, y_train)
    y_train2 = clf2.predict(X_train)
    print('accu (train): %5.2f' % (metric(y_train, y_train2)))
    
    # Random forest
    print('\nRandom Forest')
    clf3 = RandomForestClassifier(max_depth=TREE_DEPTH, n_estimators=NUM_WEAK_CLASSIFIERS)
    clf3.fit(X_train, y_train)
    y_train3 = clf3.predict(X_train)
    print('accu (train): %5.2f' % (metric(y_train, y_train3)))

    clfs = [clf1, clf2, clf3]

  elif mode is 'q':
    print('doing quantum...')

    # Qboost
    print('\nQBoost')
    clf4 = QBoostClassifier(n_estimators=NUM_WEAK_CLASSIFIERS, max_depth=TREE_DEPTH)
    clf4.fit(X_train, y_train, emb_sampler, lmd=lmd, **DW_PARAMS) # using Dwave
    y_train4 = clf4.predict(X_train)
    print(clf4.estimator_weights)
    print('accu (train): %5.2f' % (metric(y_train, y_train4)))
    clfs = [clf4]
    
    # QboostPlus temperary not support
    # print('\nQBoostPlus')
    # clf5 = QboostPlus([clf1, clf2, clf3, clf4])
    # clf5.fit(X_train, y_train, emb_sampler, lmd=lmd, **DW_PARAMS) # using Dwave
    # y_train5 = clf5.predict(X_train)
    # print(clf5.estimator_weights)
    # print('accu (train): %5.2f' % (metric(y_train, y_train5)))
    # clfs.append(clf5)

  else:
    print("mode (%s) unknown or unspecified (c=classical, q=quantum)" % mode)

  trained_model_clfs = clfs

  return trained_model_clfs


def metric(y, y_pred):
  """
  :param y: true label
  :param y_pred: predicted label
  :return: metric score
  """
  return metrics.accuracy_score(y, y_pred)


def model(trained_model, input_testing_dataset_pd):
  """ 
  :param trained_model: Trained mode
  :param input_testing_dataset_pd: Test Dataset (Pandas Dataframe)
  :return: output_accuracy_float
  """
    # dataset preparation ...
  """
  :param X_test: testing data
  :param y_test: testing label
  """
  label = 'Survived' # label for labeling training set, change it upon your preference
  X_test = input_testing_dataset_pd.loc[:,input_testing_dataset_pd.columns!=label]
  y_test = 2*(input_testing_dataset_pd[label]>0) - 1
  
  N_test = len(X_test)
  print("\n======================================")
  print("Test size: %d" % N_test)
  
  # Preprocessing data
  # imputer = preprocessing.Imputer()
  imputer = SimpleImputer(missing_values=np.nan, strategy='mean')
  scaler = preprocessing.StandardScaler()
  normalizer = preprocessing.Normalizer()

  X_test = scaler.fit_transform(X_test)
  X_test = normalizer.fit_transform(X_test)

  clf1 = trained_model[0] # default using the first one from the list, classical.index=0,1,2, quantum.index=0
  y_test1 = clf1.predict(X_test)
  
  print("using classifier:", clf1)
  print('accu (test): %5.2f'%(metric(y_test, y_test1)))

  output_accuracy_float = metric(y_test, y_test1)

  return output_accuracy_float


########## ML Model API ##################################################

def quantum_machine_learning(input_training_dataset_pd, input_testing_dataset_pd):
  """ 
  :quantum_machine_learning
  :param input_training_dataset_pd: Train Dataset (Pandas Dataframe)
  :param input_testing_dataset_pd: Train and Test Dataset (Pandas Dataframe)
  :return: output_accuracy_float
  """
  train_model = train_machine_learning_process(input_training_dataset_pd, mode='q') # mode: q=quantum,
  output_accuracy_float = model(train_model, input_testing_dataset_pd)
  return output_accuracy_float

def classical_machine_learning(input_training_dataset_pd, input_testing_dataset_pd):
  """ 
  :classical_machine_learning
  :param input_training_dataset_pd: Train Dataset (Pandas Dataframe)
  :param input_testing_dataset_pd: Train and Test Dataset (Pandas Dataframe)
  :return: output_accuracy_float
  """
  train_model = train_machine_learning_process(input_training_dataset_pd, mode='c') # mode: c=classical
  output_accuracy_float = model(train_model, input_testing_dataset_pd)
  return output_accuracy_float
