import logging
from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python_operator import PythonOperator, BranchPythonOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.models import Variable
import pandas as pd
import sys
sys.path.append('/opt/airflow/dags/pylib')

# import ETL and ML API here
from qubo_featureselection import classical_feature_selection, quantum_feature_selection
from qubo_minlossfunc import classical_machine_learning, quantum_machine_learning

dataset = pd.read_csv('/opt/airflow/dags/train.csv')
fs_dataset = dataset.drop(['Name', 'Ticket', 'Sex', 'Cabin', 'Embarked'], axis=1).dropna()
ml_dataset = dataset[['PassengerId', 'Survived', 'Pclass']]

def check_etl_type(quantum_etl, **kwargs):
    # Method 1 to pass variable, can be set in http://localhost:8080/variable/list/
    new_val = Variable.get("quantum_etl_mode", default_var=None)
    if new_val != None:
        quantum_etl = new_val

    # Method 2 to pass config, can be set when run and select "Trigger DAG w/ config"
    if "quantum_etl_mode" in kwargs['dag_run'].conf:
        logging.info('Detect custom quantum_etl_mode', kwargs['dag_run'].conf['quantum_etl_mode'])
        quantum_etl = kwargs['dag_run'].conf['quantum_etl_mode']
    
    logging.info(dataset)

    if quantum_etl:
        return 'quantum_etl_pipeline'
    else:
        return 'classical_etl_pipeline'

def check_ml_type(quantum_ml, **kwargs):
    # Method 1 to pass variable, can be set in http://localhost:8080/variable/list/
    new_val = Variable.get("quantum_ml_mode", default_var=None)
    if new_val != None:
        quantum_ml = new_val
    
    # Method 2 to pass config, can be set when run and select "Trigger DAG w/ config"
    if "quantum_ml_mode" in kwargs['dag_run'].conf:
        logging.info('Detect custom quantum_ml_mode', kwargs['dag_run'].conf['quantum_ml_mode'])
        quantum_ml = kwargs['dag_run'].conf['quantum_ml_mode']
    
    if quantum_ml:
        return 'quantum_ml_pipeline'
    else:
        return 'classical_ml_pipeline'

def classical_etl_pipeline():
    logging.info('Running Classical ETL Pipeline')
    #Call Classical ETL pipeline API
    post_fs_data = classical_feature_selection(fs_dataset)
    logging.info(post_fs_data)


def quantum_etl_pipeline():
    logging.info('Running Quantum ETL Pipeline')
    #Call Quantum ETL pipeline API
    post_fs_data = quantum_feature_selection(fs_dataset)
    logging.info(post_fs_data)

def classical_ml_pipeline():
    logging.info('Running Classical ML Pipeline')
    #Call Classical ML pipeline API
    accuracy = classical_machine_learning(ml_dataset, ml_dataset)
    logging.info('Classical ML Accuracy', accuracy)

def quantum_ml_pipeline():
    logging.info('Running Quantum ML Pipeline')
    #Call Quantum ML pipeline API
    accuracy = quantum_machine_learning(ml_dataset, ml_dataset)
    logging.info('Quantum ML Accuracy', accuracy)

default_args = {
    'owner': 'AllenWu',
    'start_date': datetime(2022, 11, 4),
    'schedule_interval': '@daily',
    'retries': 0,
    'retry_delay': timedelta(minutes=5),
    'quantum_etl_mode': True,
    'quantum_ml_mode': False,
}

with DAG(dag_id='quantum_pipeline', catchup=False, default_args=default_args) as dag:
    # Start point of ETL Pipeline 
    etl_pipeline_start = DummyOperator(
        task_id='etl_pipeline_start'
    )

    '''
    setup_etl_env = BashOperator(
        task_id='setup_etl_env',
        bash_command="scripts/etl.sh",
        dag=dag,
        )
    '''

    check_etl_type = BranchPythonOperator(
        task_id='check_etl_type',
        python_callable=check_etl_type,
        op_args=[dag.default_args['quantum_etl_mode']],
        dag=dag,
    )

    classical_etl_pipeline = PythonOperator(
        task_id='classical_etl_pipeline',
        python_callable=classical_etl_pipeline
    )

    quantum_etl_pipeline = PythonOperator(
        task_id='quantum_etl_pipeline',
        python_callable=quantum_etl_pipeline
    )

    # End point of ETL Pipeline 
    etl_pipeline_end = DummyOperator(
        task_id='etl_pipeline_end',
        trigger_rule='one_success'
    )

    
    # Start point of ML Pipeline 
    ml_pipeline_start = DummyOperator(
        task_id='ml_pipeline_start'
    )

    '''
    setup_ml_env = BashOperator(
        task_id='setup_ml_env',
        bash_command="scripts/ml.sh",
        dag=dag,
        )
    '''

    check_ml_type = BranchPythonOperator(
        task_id='check_ml_type',
        python_callable=check_ml_type,
        op_args=[dag.default_args['quantum_etl_mode']],
        dag=dag,
    )

    classical_ml_pipeline = PythonOperator(
        task_id='classical_ml_pipeline',
        python_callable=classical_ml_pipeline
    )

    quantum_ml_pipeline = PythonOperator(
        task_id='quantum_ml_pipeline',
        python_callable=quantum_ml_pipeline
    )

    # End point of ML Pipeline 
    ml_pipeline_end = DummyOperator(
        task_id='ml_pipeline_end',
        trigger_rule='one_success',
    )

    # Workflow
    etl_pipeline_start >> check_etl_type >> [classical_etl_pipeline, quantum_etl_pipeline] >> etl_pipeline_end >> ml_pipeline_start >> check_ml_type >> [classical_ml_pipeline, quantum_ml_pipeline] >> ml_pipeline_end
