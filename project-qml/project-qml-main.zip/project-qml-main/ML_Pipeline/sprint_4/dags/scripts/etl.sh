#Install the package here
echo $PWD >| /opt/airflow/dags/scripts/etl_working_dir.txt