sudo apt-get update
sudo apt-get install zip unzip
curl https://codeload.github.com/dwavesystems/qboost/zip/refs/heads/master -o qboost-master.zip
unzip qboost-master.zip
mv qboost-master/qboost /opt/airflow/dags/pylib/.
rm -rf *
su airflow
pip install --target . scikit-learn
pip install --target . dwave-system
pip install --target . dwave-ocean-sdk
pip install --target . dimod
mv * /opt/airflow/dags/pylib/.