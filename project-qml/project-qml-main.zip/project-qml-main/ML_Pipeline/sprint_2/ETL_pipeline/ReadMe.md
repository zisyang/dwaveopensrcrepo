The file train_model is the orchestrator file.

The ETL file has data ingestion and processing along with DB operations.

Steps to test.
1. Make sure both files are in the same directory.
2. Run train_model.py
3. Expected results are attached as image


Notes : Make sure that the connection string is as per your local DB instance.
The model is not deployed but set as a placeholder. The details will be added when deploying the actual models.

