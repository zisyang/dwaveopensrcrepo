import pandas as pd
from sqlalchemy import create_engine
import psycopg2
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from pyspark.sql import SQLContext
import pyspark
from pyspark.sql import SparkSession

class titanic_data:

    def __init__(self):

        #starting spark session
        self.scSpark = SparkSession\
            .builder.config("spark.jars","/opt/postgresql-42.5.0.jar") \
                .master("local")\
                    .appName("ETL") \
                        .getOrCreate()
    #reading SQL as DF

    def db_to_df(self):

        #reading from DB
        df = self.scSpark.read.format("jdbc")\
            .option("url","jdbc:postgresql://localhost:5433/test").\
                option("dbtable","titanic_dataset")\
                    .option("user","postgres")\
                        .option("password","pass")\
                            .option("driver", "org.postgresql.Driver")\
                                .load()
        #df = pd.read_sql("select * from titanic_dataset", self.conn)
        print(df.printSchema())
        return df
    

    
    def process_data(self, df):
        
        #transform

        df= df.toPandas()

        df.drop(["Name","Cabin","PassengerId","Parch"],inplace=True,axis=1)

        values={'Age':df['Age'].mean(),'Fare':df['Fare'].mean()}

        df.fillna(value=values)

        # enc = OneHotEncoder()
        # enc_values = enc.fit_transform(df['Pclass'])
        
        return df

    def split_data(self,df):
        target = "Survived"
        y = np.array(df[target])
        df.drop([target],inplace = True, axis=1)
        X = np.array(df)

        X_train,X_test,y_train,y_test = train_test_split(X,y,test_size = 0.2, random_state = 42)

        return X_train,X_test,y_train,y_test

    def df_to_db(self,df):

        #load
        
        spark_df=self.scSpark.createDataFrame(df)
        spark_df.write.model("overwrite")\
            .format("jdbc")\
                .option("url","jdbc:postgresql://localhost:5433/test")\
                    .option("dbtable","titanic_dataset_ETL")\
                        .option("user","postgres")\
                            .option("password","pass")\
                                .option("driver", "org.postgresql.Driver")\
                                    .save()

        df.to_sql('titanic_dataset_ETL', con=self.conn, if_exists='replace', index=False)
