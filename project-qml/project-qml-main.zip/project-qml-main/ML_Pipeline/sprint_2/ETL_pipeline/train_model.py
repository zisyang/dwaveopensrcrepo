import pandas as pd
import numpy as np
import ETL 
#import spark_init
from sklearn.linear_model import LogisticRegression



class model:

    def __init__(self):
        self.lr_model = LogisticRegression()
        
    
    def gen_data(self):
        t_data = ETL.titanic_data()
        df = t_data.db_to_df()
        df = t_data.process_data(df)
        ETL.df_to_db(df)
        X_train,X_test,y_train,y_test = t_data.split_data(df)
        return X_train,X_test,y_train,y_test

    def model_train(self,X_train,y_train):
        #self.lr_model.fit(X_train,y_train)
        print("model has been trained")

    def test_model(self,X_test,y_test):
        # score = self.lr_model.score(X_test,y_test)
        # print(score)
        print("model has been tested")

if __name__ == "__main__":

    #scSpark = spark_init()
    lrm = model()
    X_train,X_test,y_train,y_test = lrm.gen_data()
    lrm.model_train(X_train,y_train)
    lrm.test_model(X_test,y_test)
    

